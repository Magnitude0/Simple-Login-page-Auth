import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Building, LogOut, User, Settings } from "lucide-react";

const Dashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-muted"></div>
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gold/5 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-bronze/5 rounded-full blur-3xl animate-float" style={{ animationDelay: "1s" }}></div>
      
      {/* Header */}
      <header className="relative z-10 border-b border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warm-gradient rounded-lg flex items-center justify-center shadow-glow">
              <Building className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold bg-warm-gradient bg-clip-text text-transparent">
              ClientConnect
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <User className="w-4 h-4 mr-2" />
              Profile
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Welcome Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-warm-gradient bg-clip-text text-transparent">
              Welcome to Your Dashboard
            </h2>
            <p className="text-xl text-muted-foreground">
              Your client management platform is ready to use
            </p>
          </div>

          {/* Placeholder Content */}
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div
                key={item}
                className="bg-surface-gradient border border-border/50 rounded-xl p-6 shadow-elegant hover:shadow-glow transition-all duration-300 hover:scale-105"
              >
                <div className="w-12 h-12 bg-warm-gradient rounded-lg flex items-center justify-center mb-4 shadow-glow">
                  <Building className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2 text-foreground">
                  Feature {item}
                </h3>
                <p className="text-muted-foreground">
                  This is a placeholder for feature {item}. Your application content will go here.
                </p>
              </div>
            ))}
          </div>

          {/* Status Message */}
          <div className="mt-12 text-center">
            <div className="inline-flex items-center gap-2 bg-surface-gradient border border-border/50 rounded-lg px-6 py-3 shadow-elegant">
              <div className="w-2 h-2 bg-gold rounded-full animate-pulse"></div>
              <span className="text-muted-foreground">Dashboard is ready for customization</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;